<a href="https://www.freepik.com/free-vector/nature-roadside-background-scene_40169781.htm#page=3&query=game%20background&position=16&from_view=keyword&track=ais">Image by brgfx</a> on Freepik

https://www.freepik.com/free-vector/nature-roadside-background-scene_40169781.htm#page=3&query=game%20background&position=16&from_view=keyword&track=ais

https://pixabay.com/sound-effects/search/success/

